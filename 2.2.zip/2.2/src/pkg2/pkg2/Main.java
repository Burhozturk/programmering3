/*
 *Programmet beregner arealet af en cirkel 
 *og udskriver værdien
 */
package pkg2.pkg2;

/**
 *
 * @author burhan
 * 
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        double areal;
        int radius=14;
        areal=14*14*3.14;
        System.out.println("Arealet for cirklen med radius"+radius);
        System.err.println("er " +areal);
        
        
    }
    
}

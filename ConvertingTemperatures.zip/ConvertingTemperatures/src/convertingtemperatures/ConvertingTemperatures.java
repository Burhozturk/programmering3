/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package convertingtemperatures;
import java.util.Scanner;
/**
 *
 * @author burhan
 */
public class ConvertingTemperatures {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        double fahrenheit = 0;
        double celsius=0;
        
        
        Scanner input=new Scanner(System.in);
        System.out.println("Indtast fahrenheit");
        fahrenheit=input.nextDouble();
        celsius=(5.0/9)*(fahrenheit-32);
        System.out.println("Antal fahrenheit"+ fahrenheit + " Giver "+celsius+"celsius");
    }
    
}
